module.exports = {
  tokenBot: "8415446484:AAG_7_wCnuhObd5XWOSoPdP8_-hddsEgEmw", 
  ownerID: "8545350752",
  CHANNEL_USERNAME: "sylentexc" //ISI USERNAME CHANNEL MU TANPA AWALAN @
};
